/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package foodmeterproject;

/**
 *
 * @author al-sany
 */
public class User {
    private double height;
    private double weight;
    private String gender;
    private double age;
    private double BMI;
    private String bmi;
    public User(){
        
    }
    public User(String h,String w,String g,String a){
        this.height=Double.parseDouble(h);
        this.weight=Double.parseDouble(w);
        this.gender=g;
        this.age=Double.parseDouble(a);
    }
    
    public User(double h,double w,String g,String a){
        this.height=h;
        this.weight=w;
        this.gender=g;
        this.age=Double.parseDouble(a);
    }
    
    public double getAge(){
        return age;
    }
    
    public String getGender(){
        return gender;
    }
    
    public String calculateBMI(){
        BMI=weight/(height*height);
        bmi=Double.toString(BMI);
        return bmi;
    }
    
    public String getBMI(){
        return bmi;
    }
    
    public String calculateCalories(){
        String c;
        if(gender.equals("Male")||gender.equals("Other")){
            double cal=66+(13.7*weight)+(5*height*100)-(6.8*age);
            cal=cal*1.55;
            c=String.format("%.2f", cal);
            
        }
        else{
            double cal=655+(9.6*weight)+(1.8*height)-(4.7*age);
            cal=cal*1.55;
            c=String.format("%.2f", cal);
        }
     return c;
    }
}
